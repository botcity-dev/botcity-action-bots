from botcity.plugins.slack import BotSlackPlugin, Message, Color, Author, Footer, Field

client = BotSlackPlugin(slack_token="", channel='temp_slack_error_notification')
# client = BotSlackPlugin(slack_token="", channel="temp_slack_error_notification")

message = Message(
    text="Do you want to continue the operation? Type it: ",
    title="Error",
    color=Color.RED,

)
# Sets fields
message.fields = [Field(title="1", value="Yes", short=False, ), Field(title="2", value="No", short=False)]

response_message = client.send_message(message=message)

replies = client.wait_for_reply(response=response_message)

while True:
    for reply in replies:
        print(reply.get("member").get("name"))
        if reply.get("member").get("name").lower() == "kayque.govetri":
            if int(reply.get("text")) == 1:
                response = "Yes"
            else:
                response = "No"

            client.reply(response=client.get_replies(response_message), msg=f"Your answer was {response}")
            break
        else:
            continue
    replies = client.wait_for_reply(response=response_message)

print(reply)
